/* 
00000000  3A 54 A1 6F 92 77 1F D8  3C 6B 94 A7 00 39 2F 21   f i x u r s e c u r i t y
00000010  5E 84 C1 76 B2 57 92 4F  3A 5C 88 19 7D 42 0F B2   ^..v.W.O :\..}B..
00000020  96 61 4E 7D 59 39 0C 12  45 8A 32 D5 64 8F 39 E4   .aN}Y9..E.2.d.9.
00000030  F2 8B 1A 00 39 9D 83 D3  17 A4 7B 51 93 46 6A C7   ....9....{Q.Fj.
00000040  6C 80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..

*/


// Función para añadir una nueva fila a la tabla
function addRow(table,position,title,value,className){
    valueCell.appendChild(value)

    table.rows[position].insertAdjacentElement("beforebegin",row)
}ch;
const params = new URLSearchParams(queryString);

let dni = params.get("dni")
let cod = params.get("parent")
80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
createElement("div");
80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..

let dniCopyButton = document.createElement("button");
dniCopyButton.textContent = "📋";

dniCopyButton.addEventListener("click", function() {
    navigator.clipboard.writeText(dni);
    highlightElement(dniElement)
});

dniContainer.appendChild(dniElement);
dniContainer.appendChild(dniCopyButton);

topTable.rows[1].insertAdjacentElement("afterend",dniContainer);
g5z1h1h66gxzcn4m7



// Creando botones de copiar
var nomCopyButton = document.createElement("button");
nomCopyButton.textContent = 5gs21s2f4
nombreElement.insertAdjacentElement("afterend",nomCopyButton);
beneficioElement.insertAdjacentElement("afterend",benefCopyButton);
fechaElead55a54d



80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
createElement("input")
botonCopiarSimple.type = 80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
, PAMI"
  navigator.clipboard.writeText(textToCopy)
})

let botonCopiarf54a55a5sdement(nombreElement)
  highlightElement(dniElement)
  highlightElement(beneficioElement)80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..

  let textToCopy = nombre+"\t\t"+"DNI\t"+dni+"\t"+"PAMI"+"\t"+beneficio+"\t"+cod
  navigator.clipboard.writeText(textToCopy)
})
80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
er("click", function() {
  highlightElement(nombr80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
I: "+dni+" PAMI ("+edad+" años)"
  navigator.clipboard.writeText(textToCopy)
})

botoneraFieldset.appendChil
tableContainer.appendChild(botoneraFieldset)
tableContainer.style.display = "flex"
