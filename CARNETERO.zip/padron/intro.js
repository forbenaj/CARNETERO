80 3E 54 9A 180 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..

80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
ct() {
    const form = document.getElementById("form2")
    const dniInput = document.querySelector('[name="nroDocumento"]')
    
    form.setAttribute("action", "result.php?c=6-2-2&dni="+dniInput.value);
    form.submit();  
}


// Agarra el botón "buscar" del dni
const buttons = document.qu80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
orAll('.botonConsultar');
80 3E 54 9A 1B 6F 02  F9 42 75 3E 8D 32 84 9A   l.>T..o..Bu>.2..
