/*document.getElementById("beneficio").setAttribute("onchange","updateQR()");
document.getElementById("cod").setAttribute("onchange","updateQR()");
function updateQR(){
var beneficio = document.getElementById("beneficio").value;
var cod = document.getElementById("cod").value;

var qrsrc = "https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl="+beneficio+"-"+cod;

document.getElementById("qr").setAttribute("src",qrsrc);

}*/
console.log("This is a popup!")